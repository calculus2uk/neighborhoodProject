Neighborhood Map

To run the app simply download the project files and run index.html locally on your browser.